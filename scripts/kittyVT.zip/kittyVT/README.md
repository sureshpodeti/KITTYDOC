# kittyVT


This repo is to maintain Kittychef verification tool (KittyVT)

Install python version 3.6+ from: https://www.python.org

Verify Version of python installed 

```
python --version
```

or 

```
python3 --version
```

Install dependencies using:

```
pip install -r requirement.txt
```
