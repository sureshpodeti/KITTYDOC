import argparse
import os
import math
import zipfile
from fpdf import FPDF
from pathlib import Path
import pandas as pd
from pandas import ExcelWriter
import sys
import time

categoriesPath = "categories"
ingredientsPath = "ingredients"
menuItems = "menuItems"
workingPath = "/tmp"
resultFile = time.strftime("%Y%m%d-%H%M%S")
menuItemImagePath = "images"

def extractZip(path):
    with zipfile.ZipFile(path, 'r') as zip_ref:
        zip_ref.extractall(workingPath)
    

def imageVerifier(pathToZip):

    fileName = Path(pathToZip).stem

    path = os.path.join(workingPath, fileName, menuItems, menuItemImagePath)

    required_size = 50

    d = {'imagePath': [], 'imageSizeInKb': [], 'comment': []}

    for subdir, dirs, files in os.walk(path):
        for filename in files:
            filepath = subdir + os.sep + filename

            if filepath.endswith(".jpg") or filepath.endswith(".png"):
                size = os.path.getsize(filepath)/1024

                d['imagePath'].append(filename)
                d['imageSizeInKb'].append(size)
                
                if(size>required_size):
                    d['comment'].append('Not OK')
                else:
                    d['comment'].append('OK')

    return pd.DataFrame(d) 


def categoriesVerfier(pathToZip):
  
    fileName = Path(pathToZip).stem

    path = os.path.join(workingPath, fileName, menuItems, 'menu.xlsx')

    df = openExcel(path)

    categoriesColData = df['Category']

    categoriesColData.fillna("", inplace = True) 
    
    categoriesList = categoriesColData.tolist()
    
    categoriesResultSet = set() 

    for data in categoriesColData:
        if data is not '':
            categoriesResultSet.add(data.strip())

    categories = set()

    iPath = os.path.join(workingPath, fileName, categoriesPath)

    for subdir, dirs, files in os.walk(iPath):
        for filename in files:
            f = filename.split('.')[0]
            categories.add(f.strip())

    d = {'categoryName': [], 'comment': []}

    for exCat in categoriesResultSet:

        d['categoryName'].append(exCat)
        if exCat in categories:
            d['comment'].append('Matched')
        else:
            d['comment'].append('Did not match')

    return pd.DataFrame(d)



def ingredientsVerifier(pathToZip):

    fileName = Path(pathToZip).stem

    path = os.path.join(workingPath, fileName, menuItems, 'menu.xlsx')

    df = openExcel(path)

    ingredientsColData = df['Ingredients(Comma seperated)']
    ingredientsColData.fillna("", inplace = True) 
    
    ingredientsList = ingredientsColData.tolist()
    
    ingredientResultSet = set() 

    for data in ingredientsColData:
        splittedData = data.split(',')
        for s in splittedData:
            if s is not '':
                ingredientResultSet.add(s.strip())

    ingredients = set()

    iPath = os.path.join(workingPath, fileName, ingredientsPath)

    for subdir, dirs, files in os.walk(iPath):
        for filename in files:
            f = filename.split('.')[0]
            ingredients.add(f.strip())

    d = {'ingredientName': [], 'comment': []}

    for exIng in ingredientResultSet:
        d['ingredientName'].append(exIng)

        if exIng in ingredients:
           d['comment'].append('Matched')
        else:
             d['comment'].append('Did not match')
    
    return pd.DataFrame(d)


def menuItemsVerifier(pathToZip):
    fileName = Path(pathToZip).stem

    path = os.path.join(workingPath, fileName, menuItems, 'menu.xlsx')

    df = openExcel(path)

    menuImageTypeColData = df['Images Type(Pilot project purpose only)']
    menuImageTypeColData.fillna("", inplace = True) 
    
    menuImageTypeList = menuImageTypeColData.tolist()
    
    menuImageTypeResultSet = set() 

    for data in menuImageTypeColData:
        if data is not '':
            menuImageTypeResultSet.add(data.strip())

    menuImageTypes = set()

    iPath = os.path.join(workingPath, fileName, menuItems, menuItemImagePath)

    for subdir, dirs, files in os.walk(iPath, topdown=False):
        for name in dirs:
            menuImageTypes.add(name.strip())
       
    d = {'menuItemName': [], 'comment': []}

    for exImg in menuImageTypeResultSet:
        d['menuItemName'].append(exImg)

        if exImg in menuImageTypes:
            d['comment'].append('Matched')
        else:
            d['comment'].append('Did not match')
           
    return pd.DataFrame(d)

def writeOutput(outputPath, list_dfs):

    excelOutputPath = os.path.join(outputPath, resultFile+'.xlsx')
    sheetNames = [
        'Image Verification', 
        'Ingredients Verification',
        'Categories Verification',
        'Menu Items Verification'
        ]
    with ExcelWriter(excelOutputPath) as writer:
        for n, df in enumerate(list_dfs):
            df.to_excel(writer, sheetNames[n])
        writer.save()

    pdf = FPDF()
    pdf.add_page()
    
    pdf.set_font("Arial", size=38)
    pdf.set_text_color(68,179,66)
    pdf.cell(200, 10, txt="KITTYCHEF", ln=1, align="C")
    pdf.set_text_color(192,192,192)
    pdf.set_font("Arial", size=18)
    pdf.cell(200, 10, txt="A Product of Rupant", ln=1, align="C")
    pdf.cell(200, 10, txt="", ln=1, align="C")


    pdf.set_font("Arial", size=20)
    pdf.set_text_color(68,179,66)
    pdf.cell(200, 10, txt="Kitty Verification Tool Results", ln=1, align="C")
    pdf.cell(200, 10, txt="", ln=1, align="C")
    
    for i in range(len(sheetNames)):
        verifierDict = {'Total': 0, 'ok': 0, 'notOk': 0}

        df = pd.read_excel(excelOutputPath, sheet_name=sheetNames[i])

        verifierDict['Total'] = df.shape[0]

        if i == 0:
            verifierDict['ok'] = (df.comment == 'OK').sum()

            verifierDict['notOk'] = verifierDict['Total'] - verifierDict['ok']

            pdf.set_font("Arial", size=18)
            pdf.set_text_color(0,0,0)
            pdf.cell(200, 10, txt="Image Verification Results", ln=1, align="C")

            pdf.set_font("Arial", size=13)
            pdf.set_text_color(153,153,153)
            pdf.cell(200, 10, txt="Total Images Verified:"+str(verifierDict['Total']), ln=1, align="C")
            pdf.cell(200, 10, txt="Found Within size limits:"+str(verifierDict['ok']), ln=1, align="C")
            if verifierDict['notOk']>0:
                pdf.set_text_color(233,30,99)
                pdf.cell(200, 10, txt="Out of file limit size:"+str(verifierDict['notOk']), ln=1, align="C")
            else:
                pdf.cell(200, 10, txt="Out of file limit size:"+str(verifierDict['notOk']), ln=1, align="C")
            pdf.cell(200, 10, txt="", ln=1, align="C")
        elif i==1:
            verifierDict['ok'] = (df.comment == 'Matched').sum()

            verifierDict['notOk'] = verifierDict['Total'] - verifierDict['ok']

            pdf.set_font("Arial", size=18)
            pdf.set_text_color(0,0,0)
            pdf.cell(200, 10, txt="Ingredients Verification Results", ln=1, align="C")

            pdf.set_font("Arial", size=13)
            pdf.set_text_color(153,153,153)
            pdf.cell(200, 10, txt="Total ingredients Verified:"+str(verifierDict['Total']), ln=1, align="C")
            pdf.cell(200, 10, txt="Matched ingredients:"+str(verifierDict['ok']), ln=1, align="C")
            if verifierDict['notOk']>0:
                pdf.set_text_color(233,30,99)
                pdf.cell(200, 10, txt="Unmatched ingredients:"+str(verifierDict['notOk']), ln=1, align="C")
            else:
                pdf.cell(200, 10, txt="Unmatched ingredients:"+str(verifierDict['notOk']), ln=1, align="C")
            pdf.cell(200, 10, txt="", ln=1, align="C")
        elif i==2:
            verifierDict['ok'] = (df.comment == 'Matched').sum()

            verifierDict['notOk'] = verifierDict['Total'] - verifierDict['ok']

            pdf.set_font("Arial", size=18)
            pdf.set_text_color(0,0,0)
            pdf.cell(200, 10, txt="Categories Verification Results", ln=1, align="C")

            pdf.set_font("Arial", size=13)
            pdf.set_text_color(153,153,153)
            pdf.cell(200, 10, txt="Total Categories Verified:"+str(verifierDict['Total']), ln=1, align="C")
            pdf.cell(200, 10, txt="Matched Categories:"+str(verifierDict['ok']), ln=1, align="C")
            if verifierDict['notOk']>0:
                pdf.set_text_color(233,30,99)
                pdf.cell(200, 10, txt="Unmatched Categories:"+str(verifierDict['notOk']), ln=1, align="C")
            else:
                pdf.cell(200, 10, txt="Unmatched Categories:"+str(verifierDict['notOk']), ln=1, align="C")
            pdf.cell(200, 10, txt="", ln=1, align="C")
        elif i==3:
            verifierDict['ok'] = (df.comment == 'Matched').sum()

            verifierDict['notOk'] = verifierDict['Total'] - verifierDict['ok']

            pdf.set_font("Arial", size=18)
            pdf.set_text_color(0,0,0)
            pdf.cell(200, 10, txt="Menu Items Verification Results", ln=1, align="C")

            pdf.set_font("Arial", size=13)
            pdf.set_text_color(153,153,153)
            pdf.cell(200, 10, txt="Total Menu items Verified:"+str(verifierDict['Total']), ln=1, align="C")
            pdf.cell(200, 10, txt="Matched menu items:"+str(verifierDict['ok']), ln=1, align="C")
            if verifierDict['notOk']>0:
                pdf.set_text_color(233,30,99)
                pdf.cell(200, 10, txt="Unmatched menu items:"+str(verifierDict['notOk']), ln=1, align="C")
            else:
                pdf.cell(200, 10, txt="Unmatched menu items:"+str(verifierDict['notOk']), ln=1, align="C")
            pdf.cell(200, 10, txt="", ln=1, align="C")
    
    pdfOutputPath = os.path.join(outputPath, resultFile+'.pdf')

    pdf.output(pdfOutputPath)
        


def openExcel(path):

    useCols = [
        'Name',
        'Description',
        'Price',
        'Tags(Comma Seperated)',
        'Images Type(Pilot project purpose only)',
        'Category',
        'Ingredients(Comma seperated)',
        'recommended',
        'veg',
        'SERVES'
    ]
    df = pd.read_excel(path, sheet_name='Sheet2', usecols=useCols)

    return df


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Welcome to KittyVT (Kitty Verification Tool)!!') 
    
    parser.add_argument('-p', action="store", dest="path", help="Path to source zip file")
    
    parser.add_argument('-o', action="store", dest="output", help="Path to output folder path")

    args = parser.parse_args()

    pathToZip  = args.path
    pathtoOutput = args.output

    extractZip(pathToZip)
    
    imageVerifierDf = imageVerifier(pathToZip)

    ingredientsVerifierDf = ingredientsVerifier(pathToZip)

    categoriesVerifierDf = categoriesVerfier(pathToZip)

    menuItemsVerifierDf = menuItemsVerifier(pathToZip)

    dfLists = [
        imageVerifierDf,
        ingredientsVerifierDf,
        categoriesVerifierDf,
        menuItemsVerifierDf
    ]

    writeOutput(pathtoOutput, dfLists)
    print("Output written to path:", pathtoOutput)







